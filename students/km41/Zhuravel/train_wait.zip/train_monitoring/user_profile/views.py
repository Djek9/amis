from django.shortcuts import render, redirect
from django.views import View
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.db import connection
from django.db import transaction
from home.models import Ticket

from .forms import SignUpForm
from .models import User

@method_decorator(login_required, name='dispatch')
class ProfileDetails(View):

    def get(self, request, pk=None):
        my_profile = False

        if not pk:
            pk = request.user.id
        if request.user.id == pk:
            my_profile = True

        user = User.objects.get(pk=pk)
        user_tickets = Ticket.objects.filter(user_id=user.id)

        return render(request, 'profile/profile.html', {'user': user, 'user_tickets': user_tickets, 'my_profile': my_profile})

    def post(self, request, pk=None):
        my_profile = False

        if not pk:
            pk = request.user.id
        if request.user.id == pk:
            my_profile = True

        with transaction.atomic():
            cursor = connection.cursor()
            cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

            cursor.callproc('TICKET_PACKAGE.DELETING', [pk])
        return redirect(reverse('user_profile:profile_details'))

        return render(request, 'profile/profile.html', {'user': user, 'user_tickets': user_tickets, 'my_profile': my_profile})


def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/user_profile/login/')

    form = SignUpForm()
    return render(request, 'profile/signup.html', {'form':form})

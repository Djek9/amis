from django.conf.urls import url
from django.contrib.auth import views as auth

from . import views

urlpatterns = [

    url(r'^profile/$', views.ProfileDetails.as_view(), name='profile_details'),

    url(r'^profile/(?P<pk>\d+)/$', views.ProfileDetails.as_view(), name='profile_details_pk'),

    url(r'^signup/$', views.signup, name='signup'),

    url(r'^login/$', auth.login, {'template_name': 'profile/login.html'}, name='login'),

    url(r'^logout/$', auth.logout, {'next_page': '/'}, name='logout'),

]

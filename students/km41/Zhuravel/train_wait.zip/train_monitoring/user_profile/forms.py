from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User
from django.forms.widgets import TextInput


class SignUpForm(UserCreationForm):
    username = forms.CharField(
        max_length=25
    )
    first_name = forms.CharField(
        max_length=25,
        required=False
    )
    last_name = forms.CharField(
        max_length=25,
        required=False
    )
    email = forms.EmailField(max_length=25,
        widget=TextInput(
            attrs={
            'class':'validate',
            'placeholder': 'USERNAME@MAIL.COM',
            'pattern':"[A-Za-z0-9._]+@[A-Za-z0-9._]+\.[A-Za-z]{2,5}",
            'title': "example USERNAME@MAIL.COM"}
            )
        )
    age = forms.IntegerField(
        max_value=150,
        min_value=1,
        required=True
    )

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1',
            'password2', 'age')

from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.views import View
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.db import connection
from django.db import transaction

from .forms import TrainForm
from home.models import Train

@method_decorator(login_required, name='dispatch')
class AdminView(View):
    template_name = 'admin/admin.html'

    def get(self, request):
        trains = Train.objects.all()
        form = TrainForm()
        return render(request, self.template_name, {'form': form, 'trains': trains})

    def post(self, request):
        trains = Train.objects.all()
        form = TrainForm(request.POST, request.FILES)
        if form.is_valid():
            # form.save()

            number = request.POST.get('number')
            wagon_quantity = int(request.POST.get('wagon_quantity'))
            places_in_wagon = int(request.POST.get('places_in_wagon'))
            price = int(request.POST.get('price'))
            start_trip = request.POST.get('start_trip')
            end_trip = request.POST.get('end_trip')
            place_from = request.POST.get('place_from')
            place_to = request.POST.get('place_to')

            with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                cursor.callproc('TRAIN_PACKAGE.CREATION', [
                    number,
                    wagon_quantity,
                    places_in_wagon,
                    price,
                    start_trip,
                    end_trip,
                    place_from,
                    place_to])

            return redirect(reverse('admin_page:admin_view'))
        return render(request, self.template_name, {'form': form, 'trains': trains})


@method_decorator(login_required, name='dispatch')
class DeleteTrain(View):

    def post(self, request, pk):
        # Train.objects.get(pk=pk).delete()
        with transaction.atomic():
            cursor = connection.cursor()
            cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

            cursor.callproc('TRAIN_PACKAGE.DELETING', [pk])
        return redirect(reverse('admin_page:admin_view'))



@method_decorator(login_required, name='dispatch')
class EditTrain(View):
    template_name = 'admin/edit_train.html'

    def get(self, request, pk):
        train = Train.objects.get(pk=pk)
        form = TrainForm(instance=train)
        return render(request, self.template_name, {'form': form, 'train': train})

    def post(self, request, pk):
        train = Train.objects.get(pk=pk)
        form = TrainForm(request.POST, request.FILES, instance=train)

        if form.is_valid():
            # form.save()

            number = request.POST.get('number')
            wagon_quantity = int(request.POST.get('wagon_quantity'))
            places_in_wagon = int(request.POST.get('places_in_wagon'))
            price = int(request.POST.get('price'))
            start_trip = request.POST.get('start_trip')
            end_trip = request.POST.get('end_trip')
            place_from = request.POST.get('place_from')
            place_to = request.POST.get('place_to')

            with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                cursor.callproc('TRAIN_PACKAGE.UPDATING', [
                    train.id,
                    number,
                    wagon_quantity,
                    places_in_wagon,
                    price,
                    start_trip,
                    end_trip,
                    place_from,
                    place_to])

            return redirect(reverse('admin_page:admin_view'))
        return render(request, self.template_name, {'form':form})

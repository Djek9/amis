from django.apps import AppConfig


class AdminPageConfig(AppConfig):
    name = 'admin_page'

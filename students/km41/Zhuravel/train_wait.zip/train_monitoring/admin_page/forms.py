from home.models import Train
from django import forms
from django.forms.widgets import NumberInput, TextInput, DateTimeInput
import datetime

class TrainForm(forms.ModelForm):
    number = forms.CharField(max_length=35)
    wagon_quantity = forms.IntegerField(
        required=True,
        widget=NumberInput(
            attrs={'class':'validate',
            'min':"1",
            'max': "100"}
            )
        )
    places_in_wagon = forms.IntegerField(
        required=True,
        widget=NumberInput(
            attrs={'class':'validate',
            'min':"1",
            'max': "100"}
            )
        )
    price = forms.IntegerField(
        required=True,
        widget=NumberInput(
            attrs={
            'class':'validate',
            'min':"1",
            'max': "1000"}
            )
        )
    start_trip = forms.DateTimeField(
        required=False,
        initial=datetime.datetime.now().strftime(
            "%Y-%m-%d %H:%M"
            ),
        widget=DateTimeInput(
            format='%Y-%m-%d %H:%M'
            ),
        input_formats=['%Y-%m-%d %H:%M']
        )
    end_trip = forms.DateTimeField(
        required=False,
        initial=datetime.datetime.now().strftime(
            "%Y-%m-%d %H:%M"
            ),
        widget=DateTimeInput(
            format='%Y-%m-%d %H:%M'
            ),
        input_formats=['%Y-%m-%d %H:%M']
        )

    place_from = forms.CharField(max_length=35)
    place_to = forms.CharField(max_length=35)

    class Meta:
        model = Train
        fields = '__all__'


from django.conf.urls import url
from django.contrib.auth import views as auth

from . import views

urlpatterns = [

    url(r'^$', views.AdminView.as_view(), name='admin_view'),

    url(r'^delete_train/(?P<pk>\d+)/$', views.DeleteTrain.as_view(), name='delete_train'),

    url(r'^edit_train/(?P<pk>\d+)/$', views.EditTrain.as_view(), name='edit_train'),

]

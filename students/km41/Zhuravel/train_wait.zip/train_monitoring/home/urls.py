from django.conf.urls import url
from . import views

urlpatterns = [

    url(r'^$', views.home, name='home'),

    url(r'^train/details/(?P<pk>\d+)/$', views.TrainDetails.as_view(), name='train_details'),

    url(r'^tickets/details/(?P<pk>\d+)/$', views.TicketsDetails.as_view(), name='ticket_details'),

]

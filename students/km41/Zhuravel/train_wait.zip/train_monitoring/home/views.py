from django.shortcuts import render, redirect
from django.views import View
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.db import connection
from django.db import transaction
from django.utils import timezone

from .models import Train, Ticket

def home(request):
    template_name = 'home/home.html'

    trains = Train.objects.all()
    return render(request, template_name, {'trains': trains})

def get_reversed_places(train):
    reversed_places = []
    available = True
    tickets = Ticket.objects.filter(train=train.id, date_of_trip=train.start_trip)
    all_train_places = train.wagon_quantity * train.places_in_wagon
    if tickets.count() == all_train_places:
        available = False
        return reversed_places, available

    for ticket in tickets:
        reversed_places.append([ticket.seat, ticket.id])
    return reversed_places, available


@method_decorator(login_required, name='dispatch')
class TrainDetails(View):

    def get(self, request, pk):
        train = Train.objects.get(pk=pk)
        reversed_places, available = get_reversed_places(train)
        places_quantity = train.wagon_quantity * train.places_in_wagon

        return render(request, 'train/details.html', {
            'train': train,
            'reversed_places': reversed_places,
            'available': available, 
            'places_quantity': places_quantity})

    def post(self, request, pk, *args, **kwargs):
        train = Train.objects.get(pk=pk)
        place = int(request.POST.get('place'))
        train_tickets = Ticket.objects.filter(train=pk, date_of_trip=train.start_trip)
        for reserved in train_tickets:
            if place == reserved.seat:
                # Validation failed, send error
                reversed_places, available = get_reversed_places(train)
                places_quantity = train.wagon_quantity * train.places_in_wagon

                return render(request, 'train/details.html', 
                    {'train': train,
                    'error': True,
                    'place': place,
                    'reversed_places': reversed_places,
                    'available': available,
                    'places_quantity': places_quantity})

        ticket_number = '{train}-{ticket}'.format(train=train.number, ticket=place)
        with transaction.atomic():
            cursor = connection.cursor()
            cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

            # Create Ticket
            new_ticket = cursor.callproc('TICKET_PACKAGE.CREATION', [
            	ticket_number, place, train.start_trip, train.id, request.user.id, ''])

        train_id = int(new_ticket[-1])
        # ticket = Ticket.objects.create(
        #     train_id=train.id,
        #     user_id=request.user.id,
        #     number='{train}-{ticket}'.format(train=train.number, ticket=place),
        #     seat=place,
        #     date_or_order=now,
        #     date_of_trip=train.start_trip)

        return redirect(reverse('home:ticket_details', args=(train_id,)))


@method_decorator(login_required, name='dispatch')
class TicketsDetails(View):

    def get(self, request, pk):
        # ticket = Ticket.objects.get(pk=pk)
        cursor = connection.cursor()
        cursor.execute('SELECT "TICKET_NUMBER", "SEAT", "DATE_OF_ORDER", "DATE_OF_TRIP", \
                               "USERNAME", "USER_ID", "TRAIN_NUMBER", "TRAIN_ID" \
                        FROM "TICKET_DETAILS_VIEW" \
                        WHERE "TICKET_ID" = {}'.format(pk))

        TICKET_NUMBER, SEAT, DATE_OF_ORDER, DATE_OF_TRIP, \
            USERNAME, USER_ID, TRAIN_NUMBER, TRAIN_ID = cursor.fetchone()

        context = {
            "TICKET_NUMBER": TICKET_NUMBER,
            "SEAT": SEAT,
            "DATE_OF_ORDER": DATE_OF_ORDER,
            "DATE_OF_TRIP": DATE_OF_TRIP,
            "USERNAME": USERNAME,
            "TRAIN_NUMBER": TRAIN_NUMBER,
            "USER_ID": USER_ID,
            "TRAIN_ID": TRAIN_ID
        }

        return render(request, 'train/ticket_details.html', context)

from django.db import models
from django.conf import settings


class Train(models.Model):
	number = models.CharField(max_length=50, null=True, unique=True)
	wagon_quantity = models.PositiveIntegerField(default=15)
	places_in_wagon = models.PositiveIntegerField(default=56)
	price = models.PositiveIntegerField()
	start_trip = models.DateTimeField(null=True)
	end_trip = models.DateTimeField(null=True)
	place_from = models.CharField(max_length=50, null=True)
	place_to = models.CharField(max_length=50, null=True)

	def __str__(self):
		return "#{number} from {place_from} to {place_to} on {start_trip}".format(
			number=self.number,
			place_from=self.place_from,
			place_to=self.place_to,
			start_trip=self.start_trip)


class Ticket(models.Model):
	train = models.ForeignKey(Train)
	user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True)
	number = models.CharField(max_length=50)
	seat = models.PositiveIntegerField()
	date_of_order = models.DateTimeField(null=True)
	date_of_trip = models.DateTimeField(null=True)

	def __str__(self):
		return 'Ticket of {user} on train {train}'.format(user=self.user, train=self.train)

	class Meta:
		unique_together = (("number", "train"),)

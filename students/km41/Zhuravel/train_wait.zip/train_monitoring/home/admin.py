from django.contrib import admin
from .models import Train, Ticket

admin.site.register(Train)
admin.site.register(Ticket)
